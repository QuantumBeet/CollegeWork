//C++ Program:		Lab11.cpp
//Course:			CSE1311 (C++) Section 002
//Name:				Vadym Strelnykov
//Assignment:		Lab 11
//Due Date:			Nov 30, 2016

//Purpose:
/*  To create a program to use functions to read numbers from a file, put them into an array, calculate the total of every row, column, and major diagonal, 
calculate whether or not the totals are the same, print everything and then, tell the user whether the boxes are magical or not. 
*/

#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <fstream>
#include <ctime>
using namespace std;

void ReadArray(ifstream&fin, int&);
int RowTotal(int);
int ColumnTotal(int);
void PrintArray ();
int MainDiag ();
int ReverseDiag();
bool isMagic ();

int x [10][10];
int size;

int main ()
{
	ifstream fin("lab11input.txt"); 
	ReadArray (fin, size);
	while (size != -1)
	{
		PrintArray();
		cout<< endl;
		for(int i = 0; i < size; ++i)
			cout << "Total of row  " << i << " is  " << RowTotal(i) << endl;
		cout << endl;
		for(int i = 0; i < size; ++i)
			cout << "Total of column  " << i << " is  " << ColumnTotal(i) << endl;
		cout << endl;
		cout << "Main diagonal total is  " << MainDiag() << endl;
		cout << "Reverse diagonal total is  "  << ReverseDiag() <<endl;

		if(isMagic())
			cout << "It is a magic box " << endl;
		else
			cout << "It is NOT a magic box " << endl;
		cout << endl;
		ReadArray (fin, size);
	}


	cout << "\nThis program was written by Vadym Strelnykov" << endl;
	system("PAUSE");
	return 0;	
}

void ReadArray (ifstream&fin, int& size)
{
	fin >> size;
	for (int i = 0; i<size; i++)
	{
		for (int j = 0; j<size; j++)
			fin >> x[i][j];
	}
}

int RowTotal (int row)
{
	int total = 0;
	for(int j = 0; j < size; ++j)
		total += x[row][j];
	return total;
}

int ColumnTotal (int column)
{
	int total = 0;
	for(int i = 0; i < size; ++i)
		total += x[i][column];
	return total;
}

void PrintArray ()
{
	for(int i = 0; i < size; ++i)
	{
		cout << "Row " << i << "\t";
		for(int j = 0; j < size; ++j)
			cout<< x[i][j] << "\t";
		cout << endl;
	}
}

int MainDiag ()
{
	int total = 0;
	for(int i = 0; i < size; ++i)
		total += x[i][i];
	return total;
}

int ReverseDiag()
{
	int total = 0;
	for(int i = 0; i < size; i++)
		total += x[i][size-1-i];
	return total;
}
bool isMagic ()
{
	bool magic = true;
	for(int i = 0; i < size; ++i)
	{
		if (RowTotal(i) != ColumnTotal(i) || MainDiag() != ReverseDiag() || RowTotal(i) != MainDiag())
			magic = false;
	}
	return magic;
}
